import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mercury',
  templateUrl: './mercury.component.html',
  styleUrls: ['./mercury.component.css']
})
export class MercuryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
