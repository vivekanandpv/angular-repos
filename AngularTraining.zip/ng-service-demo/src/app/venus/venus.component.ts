import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venus',
  templateUrl: './venus.component.html',
  styleUrls: ['./venus.component.css']
})
export class VenusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
