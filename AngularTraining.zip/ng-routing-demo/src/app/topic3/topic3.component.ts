import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topic3',
  templateUrl: './topic3.component.html',
  styleUrls: ['./topic3.component.css']
})
export class Topic3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
