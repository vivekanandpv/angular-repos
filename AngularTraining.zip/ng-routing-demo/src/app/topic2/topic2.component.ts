import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topic2',
  templateUrl: './topic2.component.html',
  styleUrls: ['./topic2.component.css']
})
export class Topic2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
